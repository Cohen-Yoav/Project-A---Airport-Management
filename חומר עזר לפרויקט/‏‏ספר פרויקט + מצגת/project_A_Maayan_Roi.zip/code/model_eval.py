import torch

class BasicModel(torch.nn.Module):
    def __init__(self):
        super(BasicModel, self).__init__()
        self.first_layer = torch.nn.Conv2d(in_channels=3, out_channels=64, kernel_size=3, stride=2, padding =1)
        self.second_layer = torch.nn.Conv2d(in_channels=64, out_channels=64, kernel_size=(4), stride=(2,2), padding=1)
        self.third_layer = torch.nn.Conv2d(in_channels=64, out_channels=64, kernel_size=(4), stride=(2,2), padding=1)
        self.fourth_layer = torch.nn.Conv2d(in_channels=64, out_channels=32, kernel_size=(4), stride=(2,2), padding=1)
        self.MaxPoolActive = torch.nn.MaxPool2d(kernel_size=2, stride=2)
        self.sigmoid = torch.nn.Sigmoid()
        self.linear = torch.nn.Linear(32, 1)

    def forward(self, x):
        y = x.double()
        out = self.first_layer(y)
        out = self.MaxPoolActive(out)
        out = self.second_layer(out)
        out = self.MaxPoolActive(out)
        out = self.third_layer(out)
        out = self.MaxPoolActive(out)
        out = self.fourth_layer(out)
        out = self.MaxPoolActive(out)
        out = out.squeeze()
        out = self.linear(out)
        out = self.sigmoid(out)
        return out.squeeze()


model = BasicModel()
model_params = torch.load('./model_18_12.pkl')
model.load_state_dict(model_params)
loss_array_train = torch.load('loss_array_train.pkl')
loss_array_test = torch.load('loss_array_test.pkl')
accuracy_epochs = torch.load('accuracy_epochs.pkl')

print(loss_array_train)
print(loss_array_test)
print(accuracy_epochs)