
from sklearn.metrics import precision_score, recall_score
import pandas as pd
from torch.utils.data import Dataset, DataLoader
import torchvision
import torch.nn as nn
import torch
from tqdm import tqdm
import pydicom
import numpy as np
import cv2


def create_train_and_test_dataframes(filename, amount_to_train, amount_to_test):
    df = pd.read_csv(filename)
    df["Image"] = df["ID"].str.slice(stop=12)
    df["Diagnosis"] = df["ID"].str.slice(start=13)
    duplicates_to_remove = [56346, 56347, 56348, 56349,
                            56350, 56351, 1171830, 1171831,
                            1171832, 1171833, 1171834, 1171835,
                            3705312, 3705313, 3705314, 3705315,
                            3705316, 3705317, 3842478, 3842479,
                            3842480, 3842481, 3842482, 3842483]
    df = df.drop(index=duplicates_to_remove)
    df = df.reset_index(drop=True)
    df = df.loc[:, ["Label", "Diagnosis", "Image"]]
    df = df.set_index(['Image', 'Diagnosis']).unstack(level=-1)

    healthy_df = df[df[('Label', 'any')] == 0]
    sick_df = df[df[('Label', 'any')] == 1]

    amount_to_train = amount_to_train // 2
    train_df = pd.concat([healthy_df[:amount_to_train], sick_df[:amount_to_train]])

    amount_to_test = amount_to_test // 2
    test_df = pd.concat([healthy_df[amount_to_train: amount_to_train + amount_to_test],
                         sick_df[amount_to_train: amount_to_train + amount_to_test]])

    return train_df, test_df

HEIGHT = 256
WIDTH = 256
CHANNELS = 3
SHAPE = (HEIGHT, WIDTH, CHANNELS)


def correct_dcm(dcm):
    x = dcm.pixel_array + 1000
    px_mode = 4096
    x[x >= px_mode] = x[x >= px_mode] - px_mode
    dcm.PixelData = x.tobytes()
    dcm.RescaleIntercept = -1000


def window_image(dcm, window_center, window_width):
    if (dcm.BitsStored == 12) and (dcm.PixelRepresentation == 0) and (int(dcm.RescaleIntercept) > -100):
        correct_dcm(dcm)
    img = dcm.pixel_array * dcm.RescaleSlope + dcm.RescaleIntercept

    # Resize
    img = cv2.resize(img, SHAPE[:2], interpolation=cv2.INTER_LINEAR)

    img_min = window_center - window_width // 2
    img_max = window_center + window_width // 2
    img = np.clip(img, img_min, img_max)
    return img


def bsb_window(dcm):
    brain_img = window_image(dcm, 40, 80)
    subdural_img = window_image(dcm, 80, 200)
    soft_img = window_image(dcm, 40, 380)

    brain_img = (brain_img - 0) / 80
    subdural_img = (subdural_img - (-20)) / 200
    soft_img = (soft_img - (-150)) / 380
    bsb_img = np.array([brain_img, subdural_img, soft_img]).transpose(1, 2, 0)
    return bsb_img


def _read(path, SHAPE):
    dcm = pydicom.dcmread(path)
    img = bsb_window(dcm)

    new_list = [img[2], img[0], img[1]]
    return img.transpose(2, 0, 1)



class CTDataset(Dataset):
    def __init__(self, imgs_path, train_df):
        self.imgs_path = imgs_path
        self.target_file = train_df
        self.ids = self.target_file.index

    def __len__(self):
        # return how many items in dataset
        return self.target_file.shape[0]

    def __getitem__(self, index):
        ID = self.ids[index]
        image = _read(self.imgs_path + ID + ".dcm", SHAPE)
        try:
            target = self.target_file.iloc[index]['Label'][0].values
        except:
            target = self.target_file.iloc[index]['Label'].values
        return image.astype('double'), target


class BasicModel(torch.nn.Module):
    def __init__(self):
        super(BasicModel, self).__init__()
        self.first_layer = torch.nn.Conv2d(in_channels=3, out_channels=64, kernel_size=3, stride=2, padding =1)
        self.second_layer = torch.nn.Conv2d(in_channels=64, out_channels=64, kernel_size=(4), stride=(2,2), padding=1)
        self.third_layer = torch.nn.Conv2d(in_channels=64, out_channels=64, kernel_size=(4), stride=(2,2), padding=1)
        self.fourth_layer = torch.nn.Conv2d(in_channels=64, out_channels=32, kernel_size=(4), stride=(2,2), padding=1)
        self.MaxPoolActive = torch.nn.MaxPool2d(kernel_size=2, stride=2)
        self.sigmoid = torch.nn.Sigmoid()
        self.linear = torch.nn.Linear(32, 6)

    def forward(self, x):
        y = x.double()
        out = self.first_layer(y)
        out = self.MaxPoolActive(out)
        out = self.second_layer(out)
        out = self.MaxPoolActive(out)
        out = self.third_layer(out)
        out = self.MaxPoolActive(out)
        out = self.fourth_layer(out)
        out = self.MaxPoolActive(out)
        out = out.squeeze()
        out = self.linear(out)
        out = self.sigmoid(out)
        return out.squeeze()


NUM_EPOCHS = 800
TRAIN_SAMPLES = 40000
TEST_SAMPLES = 10000

csv_path = '/data/maayan.k@ef.technion.ac.il/rsna-intracranial-hemorrhage-detection/stage_2_train.csv'
imgs_path = '/data/maayan.k@ef.technion.ac.il/rsna-intracranial-hemorrhage-detection/stage_2_train/'
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

train_df, test_df = create_train_and_test_dataframes(csv_path, TRAIN_SAMPLES, TEST_SAMPLES)
test_data = CTDataset(imgs_path, test_df)
test_dataloader = DataLoader(test_data, batch_size=256, shuffle=True)

my_basic_model = BasicModel()
my_basic_model.load_state_dict(torch.load('model_18_12_batch256_data50000.pkl'))
my_basic_model.eval()
model = my_basic_model.double().to(device)
#model = my_basic_model.double()

all_targets = []
all_outputs = []

with torch.no_grad():
    for batch, target in test_dataloader:

        batch = batch.to(device)
        target = target.to(device)
        all_targets.append(target.double())

        res = torch.round(model(batch))
        all_outputs.append(res.double())
        print(target, res)

torch.save(all_targets, 'targets_multi.pkl')
torch.save(all_outputs, 'outputs_multi.pkl')

targets = torch.cat(all_targets).cpu()
outputs = torch.cat(all_outputs).cpu()
precision = precision_score(targets, outputs)
recall = recall_score(targets, outputs)
print(precision)
print (recall)