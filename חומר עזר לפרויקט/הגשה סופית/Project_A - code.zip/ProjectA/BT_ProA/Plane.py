class Plane:
    def __init__(self, plane_id, sd_duration, m_duration, day_duration, init_state):
        self.plane_id = plane_id
        self.sd_duration = sd_duration
        self.m_duration = m_duration
        self.day_duration = day_duration
        self.init_state = init_state
